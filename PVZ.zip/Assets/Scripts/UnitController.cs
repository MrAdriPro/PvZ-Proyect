using UnityEngine;

public class UnitController : MonoBehaviour
{
    public UnitData unitData;

    private float currentHealth;

    private void Start()
    {
        if (unitData == null)
        {
            Debug.LogError("UnitData no est� asignado en " + gameObject.name);
            return;
        }

        currentHealth = unitData.maxHealth;


    }

    public void TakeDamage(float damage)
    {
        currentHealth -= damage;

        if (currentHealth <= 0)
        {
            Die();
        }
    }

    public void PerformAttack(GameObject target)
    {
        unitData.Attack(target);
    }

    private void Die()
    {
        Destroy(gameObject);
    }
}

